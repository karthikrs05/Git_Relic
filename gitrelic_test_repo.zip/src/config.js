export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8787/api';
